<?php $__env->startComponent('mail::message'); ?>
# Suspension de votre compte TargetDesk

Bonjour **<?php echo e($user->name); ?>**,

Nous vous informons que votre compte TargetDesk CRM a été temporairement désactivé par un administrateur.

## Informations sur la suspension

<?php $__env->startComponent('mail::panel'); ?>
**Compte :** <?php echo e($user->email); ?>

**Date de suspension :** <?php echo e(now()->format('d/m/Y à H:i')); ?>

**Statut :** Désactivé
**Raison :** <?php echo e($reason ?? 'Non spécifiée'); ?>

<?php echo $__env->renderComponent(); ?>

## Que se passe-t-il maintenant ?

- Votre accès à la plateforme TargetDesk est temporairement suspendu
- Vos données restent sécurisées et ne seront pas supprimées
- Toutes vos sessions actives ont été fermées automatiquement

## Pour réactiver votre compte

Veuillez contacter votre administrateur ou notre équipe support pour comprendre les raisons de cette suspension et les étapes nécessaires à la réactivation.

<?php $__env->startComponent('mail::button', ['url' => 'mailto:support@targetdesk.fr?subject=Réactivation de compte - ' . $user->email, 'color' => 'primary']); ?>
Contacter le support
<?php echo $__env->renderComponent(); ?>

---

**L'équipe TargetDesk**
Email: support@targetdesk.fr
Site: [targetdesk.fr](https://targetdesk.fr)

<?php $__env->startComponent('mail::subcopy'); ?>
Cette notification a été envoyée automatiquement suite à une action administrative. Si vous pensez qu'il s'agit d'une erreur, contactez immédiatement notre support.
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/resources/views/emails/user/account-deactivated.blade.php ENDPATH**/ ?>