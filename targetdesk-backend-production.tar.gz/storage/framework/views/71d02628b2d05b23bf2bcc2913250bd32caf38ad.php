<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>