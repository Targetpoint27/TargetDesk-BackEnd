<?php $__env->startComponent('mail::message'); ?>
<?php if($recipientType === 'participant'): ?>
# 📧 Rappel - Invitation à un Rendez-vous

Bonjour **<?php echo e($participantName); ?>**,

Vous êtes invité(e) à un rendez-vous prévu **<?php echo e($timeUntil); ?>** organisé par **<?php echo e($organizerName); ?>** avec :
<?php else: ?>
# 🕐 Rappel de Rendez-vous

Bonjour **<?php echo e($organizerName); ?>**,

Vous avez un rendez-vous prévu **<?php echo e($timeUntil); ?>** avec :
<?php endif; ?>

<?php $__env->startComponent('mail::panel'); ?>
## 👤 <?php echo e($client->name); ?>

**Client ID :** <?php echo e($client->client_id ?? 'N/A'); ?>

<?php if($client->industry): ?>
**Secteur :** <?php echo e($client->industry); ?>

<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

---

## 📅 Détails du Rendez-vous

<?php $__env->startComponent('mail::table'); ?>
| | |
|:--|:--|
| **📅 Date & Heure** | <?php echo e($appointment->scheduled_at->format('d/m/Y à H:i')); ?> |
| **📍 Lieu** | <?php echo e($appointment->location ?? 'Non spécifié'); ?> |
| **⏱️ Durée** | <?php echo e($appointment->duration); ?> minutes |
| **🏷️ Type** | <?php echo e(ucfirst($appointment->type)); ?> |
| **🌍 Fuseau** | <?php echo e($appointment->timezone); ?> |
<?php echo $__env->renderComponent(); ?>

<?php if($appointment->description): ?>
### 📋 Description
<?php echo e($appointment->description); ?>

<?php endif; ?>

<?php if($participants->count() > 0): ?>
### 👥 Participants
<?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
- **<?php echo e($participant->name); ?>**<?php echo e($participant->email ? " - {$participant->email}" : ''); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if($appointment->meeting_url): ?>
<?php $__env->startComponent('mail::button', ['url' => $appointment->meeting_url]); ?>
🎥 Rejoindre la visioconférence
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->startComponent('mail::button', ['url' => $clientUrl]); ?>
📋 Voir la fiche client
<?php echo $__env->renderComponent(); ?>

---

<?php if($recipientType === 'organizer'): ?>
<?php $__env->startComponent('mail::panel'); ?>
### 💡 Conseils pour votre Rendez-vous

✅ **Préparez vos documents** et questions à l'avance
✅ **Vérifiez votre matériel** (si visio)
✅ **Arrivez 5 minutes** avant l'heure
✅ **Consultez l'historique** des interactions client
<?php echo $__env->renderComponent(); ?>
<?php else: ?>
<?php $__env->startComponent('mail::panel'); ?>
### 💡 Informations importantes

✅ **Préparez-vous** pour ce rendez-vous
✅ **Vérifiez votre agenda** et disponibilité
✅ **Contactez l'organisateur** si besoin : <?php echo e($organizerName); ?>

✅ **Confirmez votre présence** si nécessaire
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php switch($reminderType):
    case ('reminder_1440m'): ?>
        🗓️ **Rappel J-1** : Rendez-vous demain !
        <?php break; ?>
    <?php case ('reminder_60m'): ?>
        ⏰ **Rappel dernière heure** : Préparez-vous !
        <?php break; ?>
    <?php case ('reminder_15m'): ?>
        🚨 **Rappel urgent** : Rendez-vous dans 15 minutes !
        <?php break; ?>
<?php endswitch; ?>

---

Excellente réunion !

**L'équipe <?php echo e(config('app.name')); ?>**

<?php $__env->startComponent('mail::subcopy'); ?>
Cet email est un rappel automatique généré par TargetDesk CRM.
Si vous ne souhaitez plus recevoir ces rappels, vous pouvez modifier vos préférences dans votre profil utilisateur.
<?php echo $__env->renderComponent(); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/resources/views/emails/appointment-reminder.blade.php ENDPATH**/ ?>