<div class="table">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/table.blade.php ENDPATH**/ ?>