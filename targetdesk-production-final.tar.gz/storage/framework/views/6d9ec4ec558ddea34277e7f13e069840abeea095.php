<?php $__env->startComponent('mail::message'); ?>
# Réactivation de votre compte TargetDesk

Bonjour **<?php echo e($user->name); ?>**,

Excellente nouvelle ! Votre compte TargetDesk CRM a été réactivé avec succès.

## Informations de réactivation

<?php $__env->startComponent('mail::panel'); ?>
**Compte :** <?php echo e($user->email); ?>

**Date de réactivation :** <?php echo e(now()->format('d/m/Y à H:i')); ?>

**Statut :** Actif
**Rôle actuel :** <?php echo e($user->roles->first()->name ?? 'Utilisateur'); ?>

<?php echo $__env->renderComponent(); ?>

## Accès restauré

Vous pouvez maintenant :
- Vous connecter à votre compte TargetDesk
- Accéder à toutes vos données précédentes
- Reprendre votre travail là où vous l'aviez laissé

<?php $__env->startComponent('mail::button', ['url' => config('app.frontend_url') . '/login', 'color' => 'success']); ?>
Se connecter à TargetDesk
<?php echo $__env->renderComponent(); ?>

## Recommandations de sécurité

Nous vous recommandons de :
- **Vérifier votre mot de passe** et le changer si nécessaire
- **Examiner vos paramètres de compte** pour vous assurer qu'ils sont corrects
- **Signaler toute activité suspecte** à notre équipe support

---

**L'équipe TargetDesk**
Email: support@targetdesk.fr
Site: [targetdesk.fr](https://targetdesk.fr)

<?php $__env->startComponent('mail::subcopy'); ?>
Si vous n'avez pas demandé la réactivation de ce compte, veuillez contacter immédiatement notre service support à support@targetdesk.fr
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/resources/views/emails/user/account-reactivated.blade.php ENDPATH**/ ?>