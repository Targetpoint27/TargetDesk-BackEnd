<?php echo e($slot); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>