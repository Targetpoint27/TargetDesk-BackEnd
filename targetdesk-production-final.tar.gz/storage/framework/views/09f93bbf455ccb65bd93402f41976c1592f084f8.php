<?php $__env->startComponent('mail::message'); ?>
# Connexion suspecte détectée

Bonjour **<?php echo e($user->name); ?>**,

Une connexion inhabituelle à votre compte TargetDesk CRM a été détectée.

## Détails de la connexion

<?php $__env->startComponent('mail::panel'); ?>
**Compte :** <?php echo e($user->email); ?>

**Date et heure :** <?php echo e($loginAttempt['timestamp'] ?? now()->format('d/m/Y à H:i')); ?>

**Adresse IP :** <?php echo e($loginAttempt['ip'] ?? 'Non disponible'); ?>

**Localisation estimée :** <?php echo e($loginAttempt['location'] ?? 'Non disponible'); ?>

**Navigateur :** <?php echo e($loginAttempt['user_agent'] ?? 'Non disponible'); ?>

**Statut :** <?php echo e($loginAttempt['status'] ?? 'Bloquée'); ?>

<?php echo $__env->renderComponent(); ?>

## Si c'était vous

Si vous reconnaissez cette connexion, aucune action n'est nécessaire. Nous surveillons votre compte pour votre sécurité.

## Si ce n'était pas vous

<?php $__env->startComponent('mail::button', ['url' => config('app.frontend_url') . '/security/change-password', 'color' => 'error']); ?>
Changer mon mot de passe immédiatement
<?php echo $__env->renderComponent(); ?>

**Actions recommandées :**
- Changez votre mot de passe immédiatement
- Vérifiez vos sessions actives et fermez celles que vous ne reconnaissez pas
- Activez l'authentification à deux facteurs si disponible
- Contactez notre support si vous avez des inquiétudes

## Mesures de sécurité prises

- Cette tentative de connexion a été <?php echo e($loginAttempt['blocked'] ? 'bloquée automatiquement' : 'surveillée'); ?>

- Nous avons renforcé la surveillance de votre compte
- Vous recevrez une alerte pour toute activité suspecte

---

**L'équipe TargetDesk**
Email: support@targetdesk.fr
Site: [targetdesk.fr](https://targetdesk.fr)

<?php $__env->startComponent('mail::subcopy'); ?>
Cette alerte est envoyée automatiquement pour votre sécurité. En cas de doute, contactez immédiatement notre support à support@targetdesk.fr
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/resources/views/emails/security/suspicious-login.blade.php ENDPATH**/ ?>