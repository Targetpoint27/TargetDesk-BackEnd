<?php $__env->startComponent('mail::message'); ?>
# Bienvenue sur TargetDesk CRM

Bonjour **<?php echo e($user->name); ?>**,

Votre compte TargetDesk CRM a été créé avec succès ! Nous sommes ravis de vous accueillir dans notre plateforme de gestion de la relation client.

## Vos informations de connexion

<?php $__env->startComponent('mail::panel'); ?>
**Email :** <?php echo e($user->email); ?>

**Mot de passe temporaire :** <?php echo e($temporaryPassword); ?>

**Rôle :** <?php echo e($user->roles->first()->name ?? 'Utilisateur'); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => config('app.frontend_url') . '/login', 'color' => 'success']); ?>
Se connecter à TargetDesk
<?php echo $__env->renderComponent(); ?>

## Sécurité importante

Pour votre sécurité, veuillez :
- **Changer votre mot de passe** lors de votre première connexion
- **Activer l'authentification à deux facteurs** si disponible
- **Ne jamais partager vos identifiants** avec qui que ce soit

## Besoin d'aide ?

Notre équipe support est à votre disposition pour vous accompagner dans la prise en main de la plateforme.

---

**L'équipe TargetDesk**
Email: support@targetdesk.fr
Site: [targetdesk.fr](https://targetdesk.fr)

<?php $__env->startComponent('mail::subcopy'); ?>
Si vous n'avez pas demandé la création de ce compte, veuillez contacter immédiatement notre service support à support@targetdesk.fr
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/resources/views/emails/user/account-created.blade.php ENDPATH**/ ?>