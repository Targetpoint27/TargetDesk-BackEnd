<?php $__env->startComponent('mail::message'); ?>
# Réinitialisation de votre mot de passe

Bonjour **<?php echo e($user->name); ?>**,

Votre mot de passe TargetDesk CRM a été réinitialisé par un administrateur.

## Nouveau mot de passe temporaire

<?php $__env->startComponent('mail::panel'); ?>
**Email :** <?php echo e($user->email); ?>

**Nouveau mot de passe :** <?php echo e($temporaryPassword); ?>

**Date de réinitialisation :** <?php echo e(now()->format('d/m/Y à H:i')); ?>

**Réinitialisé par :** <?php echo e($resetBy ?? 'Administrateur'); ?>

<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => config('app.frontend_url') . '/login', 'color' => 'success']); ?>
Se connecter maintenant
<?php echo $__env->renderComponent(); ?>

## Action requise immédiatement

Pour votre sécurité, vous devez :

1. **Vous connecter** avec ce mot de passe temporaire
2. **Changer immédiatement** votre mot de passe
3. **Choisir un mot de passe fort** (minimum 8 caractères, majuscules, minuscules, chiffres)

## Sécurité

- Ce mot de passe temporaire expire dans **24 heures**
- Votre ancienne session a été fermée automatiquement
- Ne partagez jamais vos identifiants avec qui que ce soit

---

**L'équipe TargetDesk**
Email: support@targetdesk.fr
Site: [targetdesk.fr](https://targetdesk.fr)

<?php $__env->startComponent('mail::subcopy'); ?>
Si vous n'avez pas demandé cette réinitialisation, contactez immédiatement notre service support à support@targetdesk.fr
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/resources/views/emails/user/password-reset-by-admin.blade.php ENDPATH**/ ?>