<?php $__env->startComponent('mail::message'); ?>
# Modification de vos permissions

Bonjour **<?php echo e($user->name); ?>**,

Vos permissions sur TargetDesk CRM ont été mises à jour par un administrateur.

## Détails de la modification

<?php $__env->startComponent('mail::panel'); ?>
**Compte :** <?php echo e($user->email); ?>

**Ancien rôle :** <?php echo e($oldRole ?? 'Non défini'); ?>

**Nouveau rôle :** <?php echo e($newRole); ?>

**Date de modification :** <?php echo e(now()->format('d/m/Y à H:i')); ?>

**Modifié par :** <?php echo e($modifiedBy ?? 'Administrateur'); ?>

<?php echo $__env->renderComponent(); ?>

## Nouvelles permissions

Votre nouveau rôle vous donne accès aux fonctionnalités suivantes :
<?php echo $permissions ?? 'Consultez votre profil pour voir vos nouvelles permissions.'; ?>


<?php $__env->startComponent('mail::button', ['url' => config('app.frontend_url') . '/profile', 'color' => 'primary']); ?>
Voir mon profil
<?php echo $__env->renderComponent(); ?>

## Important

- Ces modifications sont effectives immédiatement
- Vous devrez peut-être vous reconnecter pour voir les changements
- Certaines fonctionnalités peuvent maintenant être disponibles ou restreintes

---

**L'équipe TargetDesk**
Email: support@targetdesk.fr
Site: [targetdesk.fr](https://targetdesk.fr)

<?php $__env->startComponent('mail::subcopy'); ?>
Si vous avez des questions sur vos nouvelles permissions, contactez votre administrateur ou notre équipe support.
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/TargetDesk_backend/resources/views/emails/user/role-changed.blade.php ENDPATH**/ ?>